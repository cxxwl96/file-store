/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cxxwl96;

import java.util.List;

import cn.hutool.core.util.HexUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * MainClass
 *
 * @author cxxwl96
 * @since 2022/11/18 12:00
 */
@Slf4j
public class MainClass {
    public static void main(String[] args) {
        final Serial serial = new Serial().setPort(12);
        final ImuCommunication communication = new ImuCommunicationImpl();
        try {
            // 连接串口
            communication.open(serial);
            // 获取一组数据
            final List<byte[]> oneGroup = communication.groups(1);
            log.info("One group: {}", HexUtil.encodeHexStr(oneGroup.get(0), false));
            // 获取100组数据
            final List<byte[]> groups = communication.groups(100);
            for (int i = 0; i < groups.size(); i++) {
                log.info("group {}: {}", (i + 1), HexUtil.encodeHexStr(oneGroup.get(0), false));
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
        } finally {
            communication.close();
        }
    }
}
