/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cxxwl96;

import com.fazecast.jSerialComm.SerialPort;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * Serial
 *
 * @author cxxwl96
 * @since 2022/11/18 12:08
 */
@Data
@Accessors(chain = true)
public class Serial {
    // 串口号
    private int port;

    // 波特率
    private int baudRate = 406800;

    // 数据位
    private int dataBit = 8;

    // 停止位
    private int stopBit = SerialPort.ONE_STOP_BIT;

    // 停止位
    private int parity = SerialPort.NO_PARITY;

    // 超时时间
    private int timeout = 3000;
}
