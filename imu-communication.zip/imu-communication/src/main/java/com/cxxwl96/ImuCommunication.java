/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cxxwl96;

import java.util.List;

/**
 * ImuCommunication
 *
 * @author cxxwl96
 * @since 2022/11/18 12:01
 */
public interface ImuCommunication {
    /**
     * 打开串口
     *
     * @param serialParam 串口参数
     */
    void open(Serial serialParam);

    /**
     * 获取组数据
     *
     * @param groupNumber 组数据个数
     * @return 组数据
     * @throws Exception 获取组数据异常，通常是IO异常
     */
    List<byte[]> groups(int groupNumber) throws Exception;

    /**
     * 关闭串口连接
     */
    void close();
}
