/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cxxwl96;

import com.fazecast.jSerialComm.SerialPort;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.HexUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * ImuCommunicationImpl
 *
 * @author cxxwl96
 * @since 2022/11/18 12:01
 */
@Slf4j
public class ImuCommunicationImpl implements ImuCommunication {
    // 每一组数据的长度
    private final static int groupSize = 25;

    // 一组数据的头部标志
    private final static byte[] groupStartBytes = new byte[] {(byte) 0xAA, 0x36};

    // 串口参数
    private Serial serialParam;

    // 串口
    private SerialPort serialPort;

    // 串口的输入流通道
    private InputStream input;

    /**
     * 打开串口
     *
     * @param serialParam 串口参数
     */
    @Override
    public void open(Serial serialParam) {
        this.serialParam = serialParam;
        // 打开串口连接
        serialPort = SerialPort.getCommPort("COM" + serialParam.getPort());
        serialPort.setBaudRate(serialParam.getBaudRate());
        if (!serialPort.isOpen()) {
            //开启串口
            serialPort.openPort(serialParam.getTimeout());
        }
        serialPort.setFlowControl(SerialPort.FLOW_CONTROL_DISABLED);
        serialPort.setComPortParameters(serialParam.getBaudRate(), serialParam.getDataBit(), serialParam.getStopBit(),
            serialParam.getParity());
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING | SerialPort.TIMEOUT_WRITE_BLOCKING, 1000, 1000);
        // 得到串口的输入流通道
        input = serialPort.getInputStream();
    }

    /**
     * 获取组数据
     *
     * @param groupNumber 组数据个数
     * @return 组数据
     * @throws Exception 获取组数据异常，通常是IO异常
     */
    @Override
    public List<byte[]> groups(int groupNumber) throws Exception {
        try {
            /*
            如果组数据标志开放设置，请打开此校验功能
            // 组数据标志个数不能大于分组长度
            if (groupStartBytes.length > groupSize) {
                throw new IllegalArgumentException("Group tag starting length cannot be greater than the length")
            }
             */
            // 清空输入流通道数据
            final long skip = input.skip(input.available());
            log.info("Clear the input channel data, skip {} ", skip);
            // 跳过第一组，因为第一组数据可能不正确
            final byte[] bytes = nextGroup();
            log.info("Skip the first group: {}", HexUtil.encodeHexStr(bytes, false));
            // 开始接收组数据
            final ArrayList<byte[]> groups = new ArrayList<>();
            for (int i = 0; i < groupNumber; i++) {
                groups.add(nextGroup());
            }
            return groups;
        } catch (IOException exception) {
            log.error(exception.getMessage(), exception);
            throw new Exception("Error reading groups");
        }
    }

    /**
     * 获取下一个分组数据
     *
     * @return 下一个分组数据
     */
    private byte[] nextGroup() throws IOException, TimeoutException {
        final byte[] group = new byte[groupSize];
        // 查找与组数据的头部标志相同的数据
        final long startTime = System.currentTimeMillis();
        boolean found = false;
        while (System.currentTimeMillis() - startTime <= serialParam.getTimeout()) {
            found = true;
            for (int i = 0; i < groupStartBytes.length; i++) {
                final byte data = (byte) input.read();
                if (data == groupStartBytes[i]) {
                    group[i] = data;
                } else {
                    found = false;
                    break;
                }
            }
            if (found) {
                break;
            }
        }
        if (!found) {
            throw new TimeoutException("Find next group data timeout");
        }
        // 查找成功则往后读取groupSize-groupStartBytes.length个数据
        for (int i = groupStartBytes.length; i < groupSize; i++) {
            group[i] = (byte) input.read();
        }
        return group;
    }

    /**
     * 关闭串口连接
     */
    @Override
    public void close() {
        if (serialPort != null && serialPort.isOpen()) {
            serialPort.closePort();
        }
        if (input != null) {
            IoUtil.close(input);
        }
    }
}
