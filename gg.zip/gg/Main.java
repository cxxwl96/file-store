/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jad.system;

import com.jad.common.exception.ExecutionException;

import cn.hutool.core.util.IdUtil;

/**
 * Main
 *
 * @author cxxwl96
 * @since 2022/7/17 21:18
 */
public class Main {
    public static void main(String[] args) throws ExecutionException {
        final ProjectServiceImpl service = new ProjectServiceImpl();
        final Project project = new Project();
        project.setId(IdUtil.simpleUUID());
        project.setProType("测试项服务");
        project.setProVersion("v1");
        project.setName("传感器检测服务");
        project.setGroupId("com.huawei.cloudate.terminal");
        project.setArtifactId("Sensor detection service");
        project.setAuthor("cxxwl96");
        service.generate(project);
    }
}
