/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jad.system;

import com.jad.common.exception.ExecutionException;

import java.io.File;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ZipUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * ProjectServiceImpl
 *
 * @author cxxwl96
 * @since 2022/7/17 21:18
 */
@Slf4j
public class ProjectServiceImpl {
    public void generate(Project project) throws ExecutionException {
        final ProjectTemplate template = new ProjectTemplate(project);
        // 生成项目
        log.info(">>>> begin generate project");
        generateProject(new File(template.getTemplatePath()), template);
        log.info("<<<< end generate project");
        // 打包
        log.info(">>>> begin package project");
        final File[] tempFiles = new File(template.getTempPath()).listFiles();
        if (tempFiles == null) {
            log.error("temp path is null. temp path: {}", template.getTempPath());
            throw new ExecutionException("zip project fail");
        }
        final String zipPath = template.getTempPath() + File.separator + project.getArtifactId() + ".zip";
        final File zipFile = ZipUtil.zip(new File(zipPath), false, tempFiles);
        log.info("zip path: {}", zipFile.getPath());
        log.info("<<<< end package project");
        // 删除临时文件
        log.info(">>>> begin delete temp files");
        log.info("delete {}", template.getTempPath());
        FileUtil.del(template.getTempPath());
        log.info(">>>> end delete temp files");

    }

    private void generateProject(File templateFile, ProjectTemplate template) {
        if (templateFile == null || !templateFile.exists()) {
            return;
        }
        // 目标文件
        final String targetPath = template.transformTemplatePath(templateFile.getPath());
        if (templateFile.isDirectory()) {
            FileUtil.mkdir(targetPath);
            final File[] files = templateFile.listFiles();
            if (files == null) {
                return;
            }
            for (File file : files) {
                generateProject(file, template);
            }
            return;
        }
        if (templateFile.getName().endsWith(".ftl")) {
            final FreemarkerGenerator generator = new FreemarkerGenerator(template, templateFile);
            generator.processFile(null, targetPath.substring(0, targetPath.length() - 4));
        } else {
            log.info("Copy file: 'file [{}]'", targetPath);
            FileUtil.copy(templateFile.getPath(), targetPath, true);
        }
    }
}
