/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jad.system.project;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONPath;
import com.jad.common.enums.ConvertType;
import com.jad.common.exception.ExecutionException;
import com.jad.common.utils.NamingUtil;
import com.jad.generator.common.FreemarkerGenerator;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.jar.JarInputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;

/**
 * ProjectGenerator
 *
 * @author cxxwl96
 * @since 2022/7/10 15:10
 */
public class ProjectGenerator {
    // 工程信息
    private final Project project;

    // jar包内资源模板文件路径
    private final String resourcePath;

    // 解压后的模板文件路径
    private String decompressBasePath;

    // 文件生成路径
    private final String tempPath;

    public ProjectGenerator(Project project, String resourcePath) {
        this.project = project;
        this.resourcePath = resourcePath;
        final String dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
        tempPath = "temp_" + dateTimeFormat;
    }

    public void generate() throws ExecutionException {
        try {
            // 获取jar包路径
            String jarFilePath = getJarFilePath();
            // String jarFilePath = "/Users/chengyingkui/Workspace/JAD_WORKSPACE/jad-admin/system/target/system-1.0.0.jar!/BOOT-INF/classes!/";
            String jarPath = jarFilePath;
            String bootPath = "";
            // spring-boot项目打的jar包，*.jar!/BOOT-INF/classes!/
            if (jarFilePath.contains(".jar!")) {
                jarPath = jarFilePath.substring(0, jarFilePath.indexOf(".jar!") + 4);
                String temp = jarFilePath.replace(jarPath, "");
                bootPath = temp.substring(2, temp.length() - 2) + File.separator;
            }
            String resourceBasePath = bootPath + resourcePath;
            JarInputStream jarIn = new JarInputStream(new BufferedInputStream(new FileInputStream(jarPath)));
            ZipEntry entry;
            while ((entry = jarIn.getNextJarEntry()) != null) {
                if (!entry.getName().startsWith(resourceBasePath)) {
                    jarIn.closeEntry();
                    continue;
                }
                final String entryPath = entry.getName().replace(bootPath, "");
                File desTemp = new File(tempPath + File.separator + entryPath.replace(resourcePath, ""));
                if (!entry.isDirectory()) {
                    // 处理路径
                    String newPath = pathEscape(desTemp.getAbsolutePath());
                    FileUtil.mkParentDirs(newPath);
                    if (newPath.endsWith(".ftl")) {
                        newPath = newPath.substring(0, newPath.length() - 4);
                        // 生成代码
                        new FreemarkerGenerator(entryPath).processFile(project, newPath);
                    } else {
                        // 拷贝文件
                        IoUtil.copy(jarIn, new FileOutputStream(newPath));
                    }
                }
                jarIn.closeEntry();
            }
            jarIn.close();
        } catch (IOException exception) {
            throw new ExecutionException(exception.getMessage());
        }
    }

    private String getJarFilePath() throws UnsupportedEncodingException {
        // 获取当前运行的jar包路径
        String jarFilePath = getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
        jarFilePath = URLDecoder.decode(jarFilePath, "UTF-8");
        return jarFilePath.replace("file:\\", "").replace("file:", "");
    }

    private String pathEscape(String path) throws ExecutionException {
        final Matcher matcher = Pattern.compile("\\$\\{[\\w()]+}").matcher(path);
        while (matcher.find()) {
            final String group = matcher.group();
            for (ConvertType convertType : ConvertType.values()) {
                final StringBuilder value = new StringBuilder();
                if (namingEscape(group.substring(2, group.length() - 1), convertType, value)) {
                    path = path.replace(group, value);
                }
            }
        }
        return path;
    }

    private boolean namingEscape(String text, ConvertType convertType, StringBuilder result) throws ExecutionException {
        final Matcher matcher = Pattern.compile(convertType.name() + "\\(\\w+\\)").matcher(text);
        boolean found = false;
        while (matcher.find()) {
            final String group = matcher.group();
            final String field = group.substring(convertType.name().length() + 1, group.length() - 1);
            Object value = JSONPath.read(JSON.toJSONString(project), "$." + field);
            if (value == null) {
                throw new ExecutionException(field + " not exists");
            }
            try {
                final Method method = NamingUtil.class.getDeclaredMethod("to" + convertType.name(), String.class);
                value = method.invoke(null, String.valueOf(value));
            } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                throw new ExecutionException(e.getMessage());
            }
            text = text.replace(group, String.valueOf(value));
            found = true;
        }
        if (found) {
            result.setLength(0);
            result.append(text);
            return true;
        }
        return false;
    }
}
