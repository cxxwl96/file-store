/*
 * Copyright (c) 2021-2022, jad (cxxwl96@sina.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jad.system.modules.project;

import com.jad.common.lang.Result;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

import cn.hutool.core.util.IdUtil;

/**
 * ProjectController
 *
 * @author cxxwl96
 * @since 2022/7/17 23:48
 */
@RestController
@RequestMapping("/hw")
public class ProjectController {
    @Autowired
    private ProjectService service;

    @GetMapping("/generate")
    public void generate(HttpServletResponse response) {
        final Project project = new Project();
        project.setId(IdUtil.simpleUUID());
        project.setProType("测试项服务");
        project.setProVersion("v1");
        project.setName("传感器检测服务");
        project.setGroupId("com.huawei.cloudate.terminal");
        project.setArtifactId("Sensor detection service");
        project.setAuthor("cxxwl96");
        service.generate(response, project);
    }
}
